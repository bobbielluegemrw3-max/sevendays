# 08 Infrastructure

## Production Stack

Frontend:

- Vercel
- Next.js

Database/Auth/Storage:

- Supabase

Workers:

- Google Cloud Run

Queue:

- Google Pub/Sub

Secrets:

- Google Secret Manager

Monitoring:

- Google Cloud Logging
- Google Cloud Monitoring

## Worker Responsibilities

Cloud Run workers:

- daily-settlement-worker
- race-worker
- burn-worker
- assignment-worker
- buyback-worker
- mlm-worker
- liquidity-report-worker
- stress-test-worker
- liquidity-controller-worker
- notification-worker

## Rules

- Vercel does not run financial batch logic.
- Supabase Edge Functions do not run 20:00 settlement.
- Cloud Run executes all financial workers.
- Pub/Sub is used for step queues and retries.
- Supabase PostgreSQL is the only writable database.
- Workers are stateless.

## Secrets

Stored in Google Secret Manager:

- Supabase service role
- JWT secret
- Wallet secret
- RPC keys
- Encryption keys

## Monitoring

Critical alerts:

- Ledger unbalanced
- Buyback payment failed
- Batch failed
- Cash coverage below threshold
- Pub/Sub dead letter
- Service role anomaly
