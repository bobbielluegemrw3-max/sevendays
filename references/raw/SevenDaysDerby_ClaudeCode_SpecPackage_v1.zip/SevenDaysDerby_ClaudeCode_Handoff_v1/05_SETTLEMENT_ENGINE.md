# 05 Settlement Engine

## Philosophy

Settlement is the only financial execution engine.

Order:

```text
Ledger First
Ownership Second
Notification Last
```

## Daily Liquidity Settlement Batch

Runs daily at 20:00.

Steps:

1. Lock Batch
2. Lock Versions
3. Run Race
4. Confirm Race Results
5. Select Burn Targets
6. Execute Burns
7. Generate Revenge Buffs
8. Calculate Burn MLM
9. Pay Burn MLM
10. Process Day7 Clear
11. Create Buyback Schedules
12. Pay Buybacks
13. Create Memorial NFTs
14. Close Purchase Sessions
15. Select AI Profit Taking
16. Assign Buyers
17. Mint Day0 if Needed
18. Ledger Settlement
19. Transfer Ownership
20. Create Liquidity Report
21. Run Stress Tests
22. Run Liquidity Controller
23. Save Tomorrow Policy
24. Create Audit Snapshot
25. Complete Batch

## Ledger Rules

- No direct balance update.
- Double-entry ledger.
- Debit total must equal Credit total.
- Every financial transaction has idempotency_key.
- Posted ledger transactions are immutable.

## P2P Settlement

```text
Buyer locked balance debit
Seller available balance credit
Platform fee = 0
```

## Day0 Mint Settlement

```text
Buyer locked balance debit
Platform mint revenue account credit
Horse created
Ownership assigned
```

## Buyback Settlement

```text
Platform Buyback Reserve debit
User available balance credit
```

## MLM Settlement

```text
Platform MLM Reserve debit
Recipient available balance credit
```

## Retry

Retry allowed:

- Buyback payment
- MLM payment
- Notification
- Failed batch step

Retry forbidden after completion:

- Race result
- Burn result
- Posted ledger transaction
