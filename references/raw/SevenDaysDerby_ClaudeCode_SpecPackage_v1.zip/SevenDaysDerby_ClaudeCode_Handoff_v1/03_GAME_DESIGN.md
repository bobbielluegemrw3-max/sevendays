# 03 Game Design

## Game Category

Seven Days Derby is a daily strategic asset management game.

The player does not permanently train one horse.  
Because AI Profit Taking can automatically circulate horses, gameplay is designed around daily decisions.

## Daily Core Loop

```text
Purchase
↓
Assignment
↓
Daily Training Choice
↓
20:00 Race
↓
Burn or Survive
↓
Revenge Buff / Day Progress / Buyback
↓
Repeat
```

## Horse Lifecycle

```text
Day0
↓
Day1
↓
Day2
↓
Day3
↓
Day4
↓
Day5
↓
Day6
↓
Day7 Clear
↓
Buyback
↓
Memorial NFT
```

## Horse Status

- ACTIVE
- RACING_LOCKED
- BURN_PENDING
- BURNED
- AI_PROFIT_TAKING_LOCKED
- TRANSFER_PENDING
- DAY7_CLEARED
- BUYBACK_SCHEDULED
- BUYBACK_COMPLETED
- MEMORIALIZED
- SUSPENDED

## Horse Types

- SPRINTER
- POWER
- BALANCED
- ENDURANCE
- LUCK

## Rarity

- COMMON: 50%
- UNCOMMON: 25%
- RARE: 15%
- EPIC: 8%
- LEGENDARY: 2%

## Abilities

Simplified daily model:

- Speed
- Power
- Stamina
- Recovery
- Luck

## Daily Training

Player chooses one per horse per day:

- Speed Training
- Power Training
- Recovery Training

Training affects today's race only.

## Race Engine

Race Engine is deterministic and versioned.

Inputs:

- Horse snapshot
- DNA
- Horse Type
- Rarity
- Training
- Weather
- Track
- Revenge Buff
- Random seed

Output:

- Final score
- Ranking
- Burn target

## Burn Algorithm

Burn target:

```text
Bottom X%
```

X is determined by Liquidity Policy.

## Revenge Buff

Generated on Burn.

Rules:

- One active buff per user.
- Cannot be sold.
- Cannot be transferred.
- Cannot be manually used.
- Automatically applies to next purchase assignment.

## AI Profit Taking

AI Profit Taking selects eligible horses for P2P circulation.

Purpose:

- Maintain liquidity.
- Prevent inventory shortage.
- Reduce unnecessary Day0 Mint.
- Keep marketplace moving.

User cannot prevent AI Profit Taking.
