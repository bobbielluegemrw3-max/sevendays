# 09 Claude Code Guide

## Role

Claude Code is the implementation engineer.

It must follow this specification package exactly.

## Read Order

1. README.md
2. 01_CONSTITUTION.md
3. 02_BUSINESS_MODEL.md
4. 03_GAME_DESIGN.md
5. 04_ECONOMY_ENGINE.md
6. 05_SETTLEMENT_ENGINE.md
7. 06_DATABASE.md
8. 07_API.md
9. 08_INFRASTRUCTURE.md
10. 09_CLAUDE_CODE_GUIDE.md

## Implementation Order

1. Database schema
2. Ledger
3. Batch framework
4. Horse / Race / Burn
5. Revenge Buff
6. Purchase / Assignment
7. Buyback / Memorial NFT
8. Liquidity Report
9. Stress Test
10. Liquidity Controller
11. User API
12. Admin API
13. Frontend

## Repository Structure

```text
apps/
  web/
  admin/

services/
  race-worker/
  burn-worker/
  assignment-worker/
  buyback-worker/
  mlm-worker/
  liquidity-worker/
  stress-worker/
  notification-worker/

packages/
  database/
  ledger/
  shared/
  domain/
  api-contracts/

infra/
  cloudrun/
  pubsub/
  supabase/
```

## Coding Rules

- TypeScript strict mode.
- No business logic in controllers.
- Business logic belongs in domain services.
- Repository layer does not contain business logic.
- All financial operations must be transactional.
- All financial operations must be idempotent.
- All critical events must be audited.

## Forbidden Implementations

Claude Code must not implement:

- AI-controlled race outcomes.
- Platform P2P trading fees.
- Direct balance updates.
- Manual ledger mutation.
- Manual Buyback amount changes.
- Manual Revenge Buff use.
- Hall of Fame Race.
- Burn cancellation.
- Race result editing.

## Definition of Done

A feature is complete only when:

- Unit tests pass.
- Integration tests pass.
- Ledger remains balanced.
- Audit log is created.
- Idempotency is verified.
- Architecture rules are followed.
