# Seven Days Derby Claude Code Handoff

This folder is the authoritative specification package for Claude Code.

## Read Order

1. 01_CONSTITUTION.md
2. 02_BUSINESS_MODEL.md
3. 03_GAME_DESIGN.md
4. 04_ECONOMY_ENGINE.md
5. 05_SETTLEMENT_ENGINE.md
6. 06_DATABASE.md
7. 07_API.md
8. 08_INFRASTRUCTURE.md
9. 09_CLAUDE_CODE_GUIDE.md

## Master Rule

Claude Code must not invent business rules.

If implementation conflicts with these documents, these documents take precedence.

## Fixed Core Decisions

- Platform revenue = Day0 Mint only.
- Day0 Mint price = 100 USDT.
- P2P platform fee = 0%.
- Day7 Buyback = 200 USDT paid over 7 days.
- Burn generates Revenge Buff and MLM reward.
- Race Engine is deterministic and never AI-controlled.
- AI manages Liquidity / Economy only.
- Ledger is the single source of truth.
- Production stack: Vercel + Supabase + Google Cloud Run + Pub/Sub.
