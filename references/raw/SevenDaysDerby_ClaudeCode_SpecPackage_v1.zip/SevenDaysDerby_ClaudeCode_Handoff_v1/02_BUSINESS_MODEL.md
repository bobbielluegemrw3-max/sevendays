# 02 Business Model

## Core Model

Seven Days Derby monetizes only the Day0 Mint.

```text
User pays 100 USDT
↓
Day0 horse is minted
↓
Platform records Mint Revenue
```

## P2P Model

P2P trading is zero-fee.

```text
Buyer payment = Seller proceeds
Platform Fee = 0
```

Buyer cannot choose:

- Horse
- Day
- Seller

Assignment is AI-randomized from available inventory.

## Price Table

| Day | Price |
|---:|---:|
| Day0 | 100.00 |
| Day1 | 110.00 |
| Day2 | 121.00 |
| Day3 | 133.10 |
| Day4 | 146.41 |
| Day5 | 161.05 |
| Day6 | 177.16 |
| Day7 | 200.00 Buyback |

## Burn

Burn exists for:

- Supply control.
- Inflation control.
- Liquidity maintenance.
- Rebuy trigger.

Burn creates:

- Revenge Buff.
- MLM reward event.

## Day7 Buyback

When a horse clears Day7:

- It exits P2P circulation.
- Platform creates a Buyback schedule.
- Total Buyback = 200 USDT.
- Paid over 7 days.
- After all payments, Memorial NFT is created.

## Platform Margin

Target margin:

```text
Approximately 1%
```

RTP target:

```text
Approximately 99%
```

## Success KPIs

- GMV
- DAU
- Retention
- Rebuy Rate
- P2P Match Rate
- Burn Recovery Rate
- Community Growth
