# 06 Database

## Engine

Supabase PostgreSQL.

## Rules

- UUID primary keys.
- UTC timestamps.
- NUMERIC(20,8) for money.
- Financial records are immutable after posting.
- RLS enabled for user-facing access.
- Service role used only by Cloud Run / server-side APIs.

## Core Tables

- users
- ledger_accounts
- ledger_transactions
- ledger_entries
- horses
- horse_dnas
- horse_abilities
- races
- race_results
- horse_burns
- revenge_buffs
- purchase_sessions
- ownership_assignments
- ai_profit_taking_orders
- buyback_schedules
- buyback_schedule_payments
- memorial_nfts
- liquidity_policies
- daily_liquidity_reports
- liquidity_controller_runs
- stress_test_runs
- stress_test_daily_results
- batch_runs
- batch_steps
- p2p_price_tables
- p2p_price_table_items
- audit_logs
- algorithm_versions
- randomness_commits
- notifications

## Required Constraints

- One active Revenge Buff per user.
- One Buyback Schedule per horse.
- One Memorial NFT per horse.
- One Race per day.
- One Liquidity Report per day.
- Platform fee amount must equal 0.
- Buyback total amount must equal 200.
- Buyback payment days must equal 7.
- Day0 price must equal 100.

## Migration Order

1. enums
2. users
3. ledger
4. batch
5. horses
6. race
7. burn
8. revenge buffs
9. purchase sessions
10. assignments
11. buyback
12. memorial NFTs
13. liquidity
14. stress tests
15. price tables
16. audit
17. notifications
18. indexes
19. RLS
20. seed policies
