# 01 Constitution

## Purpose

Seven Days Derby is not designed to maximize player losses.

The purpose is to build a large, sustainable Web3 horse racing community through a highly liquid P2P marketplace.

## Immutable Principles

1. Player first.
2. Liquidity before platform profit.
3. Platform revenue comes only from Day0 Mint.
4. P2P platform fee is always 0%.
5. Race Engine is deterministic, versioned, auditable, and immutable.
6. AI never changes race outcomes.
7. AI manages only liquidity, reserve, forecast, and economy policies.
8. Ledger is the single source of truth.
9. Day7 Buyback is guaranteed by system rules.
10. Long-term community growth is prioritized over short-term profit.

## What This Project Is Not

Claude Code must not interpret this project as:

- A victim-generating system.
- A loss-maximizing platform.
- A Ponzi scheme.
- A player exploitation model.
- An AI-controlled race outcome engine.
- A casino that secretly manipulates results.

## What This Project Is

Seven Days Derby is:

- A Web3 horse racing game.
- A high-liquidity P2P asset marketplace.
- A deterministic racing system.
- An AI-managed economy.
- A community-first GameFi ecosystem.

## AI Boundary

AI may manage:

- Liquidity Policy.
- Reserve Ratio.
- Stress Test.
- Forecast.
- Buff table policy.
- P2P supply target.

AI must never manage:

- Race winners.
- Race rankings.
- Ledger balances.
- Buyback amount.
- P2P fee.
- Manual ownership transfer.
