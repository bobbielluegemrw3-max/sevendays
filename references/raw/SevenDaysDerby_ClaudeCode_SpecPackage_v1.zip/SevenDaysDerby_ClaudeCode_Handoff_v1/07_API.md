# 07 API

## Principles

- REST
- JSON
- JWT auth
- Cursor pagination
- Idempotency for financial operations

## User APIs

- GET /me
- GET /wallet
- GET /wallet/history
- POST /wallet/deposit
- POST /wallet/withdraw
- GET /horses
- GET /horses/{id}
- POST /purchase
- GET /purchase/{id}
- GET /assignments
- GET /races
- GET /races/{id}/results
- GET /burns
- GET /revenge-buffs/current
- GET /buybacks
- GET /buybacks/{id}/payments
- GET /memorial-nfts
- GET /notifications

## Admin APIs

- GET /admin/dashboard
- GET /admin/users
- GET /admin/horses
- GET /admin/liquidity/reports
- GET /admin/stress-tests
- POST /admin/stress-tests/run
- GET /admin/batches
- POST /admin/batches/{id}/retry
- GET /admin/buybacks
- GET /admin/audit

## Internal APIs

Cloud Run only:

- POST /internal/batch/start
- POST /internal/race/run
- POST /internal/burn/run
- POST /internal/mlm/pay
- POST /internal/buyback/pay
- POST /internal/liquidity/report
- POST /internal/stress/run

## Forbidden APIs

Do not implement:

- Race result change API
- Burn cancel API
- Manual ledger update API
- Manual Buyback amount change API
- Revenge Buff manual use API
- P2P fee setting API
- Hall of Fame Race API
