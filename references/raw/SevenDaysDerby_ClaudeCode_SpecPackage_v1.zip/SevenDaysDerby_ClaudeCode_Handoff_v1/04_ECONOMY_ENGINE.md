# 04 Economy Engine

## Objective

Economy Engine maximizes:

- Liquidity
- Community growth
- Retention
- Long-term solvency

It does not maximize short-term platform profit.

## Basic Formula

```text
Expected Profit = 100 - 200 × SurvivalRate - 10 × BurnRate
SurvivalRate + BurnRate = 1
```

Target:

```text
Day7 Arrival Rate ≈ 46.8%
Platform Profit ≈ 1.08 USDT per Day0 Mint
RTP ≈ 98.92%
```

Break-even:

```text
Day7 Arrival Rate ≈ 47.36%
```

## Reserves

Day0 Mint revenue must be allocated internally:

- Buyback Reserve
- MLM Reserve
- Operating Reserve
- Emergency Reserve
- Realized Profit

## Liquidity KPIs

- GMV
- P2P Match Rate
- Rebuy Rate
- Burn Recovery Rate
- Retention
- Day0 Mint Count
- Day7 Arrival Rate
- Cash Coverage Ratio

## Economy Status

- NORMAL
- WATCH
- WINTER
- EMERGENCY

## Winter Mode

Triggered by:

- Mint decline.
- P2P Match Rate decline.
- Cash Coverage decline.
- Buyback Liability increase.

Winter actions:

- Reduce aggressive buff policy.
- Prioritize Buyback payments.
- Allow MLM pool allocation.
- Restrict new liabilities if needed.

## Stress Tests

Run daily:

- Base
- Winter 30
- Winter 90
- High Survival
- Low Burn
- P2P Freeze
- Buff Overpower
- Mass Withdrawal

## AI Liquidity Controller

Inputs:

- Cash
- GMV
- Burn
- Mint
- Buyback Liability
- Forecast
- Rebuy Rate

Outputs:

- Tomorrow Policy
- Buff table
- P2P supply target
- Mint limit
- Reserve ratio
- Economy status

AI must not alter race outcomes.
